<h2 align="center"><u>CameraHack</u></h2>


<p align="center">
<a href="https://www.onlinehacking.in/hack-front-camera-target-phone-using-termux-linux"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a></p>
<p align="center">
    <img src="https://img.shields.io/badge/Version-2.1-blue?style=for-the-badge&color=blue">
     <img src="https://img.shields.io/github/stars/OnlineHacKing/CameraHack?style=for-the-badge&color=magenta">
  <img src="https://img.shields.io/github/forks/OnlineHacKing/CameraHack?color=cyan&style=for-the-badge&color=purple">
  <img src="https://img.shields.io/github/issues/OnlineHacKing/CameraHack?color=red&style=for-the-badge">
    <img src="https://img.shields.io/github/license/OnlineHacKing/CameraHack?style=for-the-badge&color=blue">
<br>
    <img src="https://img.shields.io/badge/Author-SUMAN-green?style=flat-square">
    <img src="https://img.shields.io/badge/Open%20Source-Yes-orange?style=flat-square">
    <img src="https://img.shields.io/badge/Maintained-Yes-cyan?style=flat-square">
    <img src="https://img.shields.io/badge/Written%20In-Shell-blue?style=flat-square">
</p>

<br>
<p align="center">
<img width="95%" src="https://i.pinimg.com/564x/60/54/46/605446a9ef85889f93c33cc66509e40b.jpg"/>
</p>

## How Works ?

First of all This tool host a phishing site on attacker local network. This tool gives two port forwarding option (NGROK or CloudFlare) to take website over the internet. Now come on the main Point, attacker simply open the tool by using terminal and generate a link, when Link is generated attacker send that link to the target. If target open the link, target ip will transfer to the attacker. After Website load, the website ask for Camera access and when target give the permission the website will take cam shots one by one and send it to the Attacker.

## Installation :
#### Link : https://www.onlinehacking.in/hack-front-camera-target-phone-using-termux-linux
`
### [+] Preview 
![Hack anyone's camera and get images](files/ch.gif)

### [+] Features
 - Two port forwarding option (NGROK or CloudFlare)
 - Live target image.
 - Easy to use
 - Gives anonymity
 - It gives you Responsive Website.
 - Three Templates
 - Get IP, Location, Device type and Browser
 - Dual Tunneling (Ngrok and Cloudflare)
 - Choose where to save images(custom directory) 
 - Error Diagnoser
 
### [+] Depenencies
 - `php`
 - `curl`
 - `wget`
 - `unzip`

## The Tool is for :

* Kali Linux
* Termux
* MacOS
* Ubuntu
* Perrot Sec OS
* Garuda Linux

## Requirements :

* Better Internet Connection
* 300 Storage

## Language is used to Make this tool

* Bash Script
* HTML
* PHP
* JavaScript
* CSS

## Warning

**CameraHack tool is only for Educational Purpose. If any user use CameraHack Tool is For illegal purpose or taking revenge, In this case the owner will not Responsible. Use of CameraHack tool is Complete Responsibility of the user. If any User misuse CameraHack tool then the tool and its owner will not Responsible.**


### [+] Disclaimer 
***This tool is developed for educational purposes. Here it demonstrates how camera phishing works. If anybody wants to gain unauthorized access to someones camera, he/she may try out this at his/her own risk. You have your own responsibilities and you are liable to any damage or violation of laws by this tool. The author is not responsible for any misuse of CameraHack!***





## 👨🏻‍💻 CONNECT WITH US :


<a href="https://github.com/OnlineHacKing"><img title="Github" src="https://img.shields.io/badge/Online-hacking-brightgreen?style=for-the-badge&logo=github"></a>
[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/suman333mondal/)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://www.onlinehacking.xyz)
[![Instagram](https://img.shields.io/badge/LINKEDIN-CONNECT-red?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/sumam333mondal/)
[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](https://fb.com/adminonlinehacking)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://telegram.dog/OnlineHacking)
<a href="https://www.youtube.com/channel/UC8pmZJAlagdZ7bb0TBlogYw"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Online Hacking-red?style=for-the-badge&logo=Youtube"></a>


# ■□■ ⚠ Warning ⚠ ■□■

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

***This information is only for educationla purpose and we are not responsible for any kind of illegal activity done by this tool***


<p style="box-sizing: border-box; color: #24292e; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;; font-size: 16px; margin-bottom: 16px; margin-top: 0px; text-align: center;"><a href="https://github.com/OnlineHacking/" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="GitHub" height="110" src="https://user-images.githubusercontent.com/64035221/96459220-834c7e00-123f-11eb-8417-534058a7ba62.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="110" />&nbsp;</a><a href="https://www.youtube.com/channel/UC8pmZJAlagdZ7bb0TBlogYw" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="YouTube" height="110" src="https://user-images.githubusercontent.com/64035221/96456596-4f238e00-123c-11eb-821e-85e9aaa3faec.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="110" />&nbsp;</a><a href="https://telegram.dog/OnlineHacking" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="Telegram" height="80" src="https://user-images.githubusercontent.com/64035221/96461243-c576bf00-1241-11eb-8fdf-139b4859bfb0.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="80" />&nbsp;</a><a href="https://www.instagram.com/suman333mondal/" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="Instagram" height="90" src="https://user-images.githubusercontent.com/64035221/96461629-3d44e980-1242-11eb-8691-46dd14355085.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="90" /></a></p>


